package com.app.contact_mohitnadipineni_c0809746android.db;

import android.content.Context;

import androidx.room.Room;
import androidx.room.RoomDatabase;

@androidx.room.Database(entities = {Contact.class}, version = 1)
public abstract class ContactListDatabase extends RoomDatabase {

    public abstract DaoInterface getDao();

    private static ContactListDatabase instance;

    public static ContactListDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context, ContactListDatabase.class, "database")
                    .allowMainThreadQueries()
                    .build();
        }
        return instance;

    }
}
