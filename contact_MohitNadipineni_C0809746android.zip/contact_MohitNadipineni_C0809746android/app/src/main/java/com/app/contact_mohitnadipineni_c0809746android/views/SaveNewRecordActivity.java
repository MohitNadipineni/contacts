package com.app.contact_mohitnadipineni_c0809746android.views;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.app.contact_mohitnadipineni_c0809746android.R;
import com.app.contact_mohitnadipineni_c0809746android.db.Contact;
import com.app.contact_mohitnadipineni_c0809746android.db.ContactListDatabase;
import com.app.contact_mohitnadipineni_c0809746android.db.DaoInterface;


public class SaveNewRecordActivity extends AppCompatActivity {

    EditText etFName, etLName, etAddress, etPhone, etEmail;
    Button btnAddContact;
    boolean isEdit;
    int id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save_new_record);
        etAddress = findViewById(R.id.etAddress);
        etEmail = findViewById(R.id.etEmail);
        etFName = findViewById(R.id.etFName);
        etLName = findViewById(R.id.etLName);
        etPhone = findViewById(R.id.etPhone);

        btnAddContact = findViewById(R.id.btnAddContact);

        if(getIntent().hasExtra("isEdit")){
            isEdit = true;
            Contact contact = (Contact)getIntent().getSerializableExtra("CONTACT");
            etAddress.setText(contact.getAddress());
            etFName.setText(contact.getEmailAddress());
            etLName.setText(contact.getLName());
            etPhone.setText(contact.getAddress());
            etEmail.setText(contact.getEmailAddress());

            id = contact.getId();
            btnAddContact.setText("Update Contact");
        }

        btnAddContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData();
            }
        });
    }

    private void saveData() {
        if (!TextUtils.isEmpty(etAddress.getText()) && !TextUtils.isEmpty(etPhone.getText()) &&
                !TextUtils.isEmpty(etLName.getText()) && !TextUtils.isEmpty(etFName.getText()) &&
                !TextUtils.isEmpty(etEmail.getText())) {
            DaoInterface daoInterface = ContactListDatabase.getInstance(getApplicationContext()).getDao();

            Contact contact = new Contact(etFName.getText().toString(), etLName.getText().toString(),
                    etEmail.getText().toString(), etPhone.getText().toString(), etAddress.getText().toString());
            if(isEdit){
                contact.setId(id);
                daoInterface.updateContactInDb(contact);
            }else{
                daoInterface.saveContactToDb(contact);
            }
            finish();
        }else {
            Toast.makeText(this, "Please enter valid data", Toast.LENGTH_SHORT).show();
        }

    }
}