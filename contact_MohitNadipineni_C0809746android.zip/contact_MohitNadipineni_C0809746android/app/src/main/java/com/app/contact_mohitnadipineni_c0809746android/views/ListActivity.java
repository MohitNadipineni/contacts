package com.app.contact_mohitnadipineni_c0809746android.views;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;

import com.app.contact_mohitnadipineni_c0809746android.R;
import com.app.contact_mohitnadipineni_c0809746android.db.Contact;
import com.app.contact_mohitnadipineni_c0809746android.db.ContactListDatabase;
import com.app.contact_mohitnadipineni_c0809746android.db.DaoInterface;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {

    RecyclerView list;
    EditText searchView;
    List<Contact> userList = new ArrayList<>();
    DaoInterface daoInterface;
    Adapter adapter;
    ExtendedFloatingActionButton fabAdd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        list = findViewById(R.id.list);
        searchView = findViewById(R.id.searchView);
        fabAdd =  findViewById(R.id.fabAdd);

        fabAdd.setOnClickListener(v -> {
            Intent intent =  new Intent(ListActivity.this, SaveNewRecordActivity.class);
            startActivity(intent);
        });

        daoInterface = ContactListDatabase.getInstance(getApplicationContext()).getDao();

        searchView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length() == 0){
                    adapter = new Adapter(userList);
                }else{
                    List<Contact> searchList = new ArrayList<>();
                    for(Contact contact: userList){
                        if(contact.getPhoneNumber().toLowerCase().contains(s.toString().toLowerCase())){
                            searchList.add(contact);
                        }
                    }
                    adapter = new Adapter(searchList);
                }
                list.setAdapter(adapter);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        userList.clear();
        userList.addAll(daoInterface.getListFromDb());
        adapter = new Adapter(userList);
        list.setAdapter(adapter);
        searchView.setText("");
    }
}