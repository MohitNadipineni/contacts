package com.app.contact_mohitnadipineni_c0809746android.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface DaoInterface {

    @Query("select * from Contact")
    List<Contact> getListFromDb();

    @Insert
    void saveContactToDb(Contact contact);

    @Update
    void updateContactInDb(Contact contact);

    @Query("delete from Contact where id=:id")
    void deleteContactFromDb(int id);

}
