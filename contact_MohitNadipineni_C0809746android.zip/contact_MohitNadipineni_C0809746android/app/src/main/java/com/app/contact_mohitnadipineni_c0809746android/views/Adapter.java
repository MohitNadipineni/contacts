package com.app.contact_mohitnadipineni_c0809746android.views;

import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListPopupWindow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.app.contact_mohitnadipineni_c0809746android.R;
import com.app.contact_mohitnadipineni_c0809746android.db.Contact;
import com.app.contact_mohitnadipineni_c0809746android.db.ContactListDatabase;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.BindViewHolder> {

    List<Contact> contactList;

    public Adapter(List<Contact> contactList){
        this.contactList = contactList;
    }

    @NonNull
    @Override
    public BindViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_cell,parent,false);
        return new BindViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BindViewHolder holder, int position) {
        holder.bindData(position);
    }

    @Override
    public int getItemCount() {
        return contactList.size();
    }

    class BindViewHolder extends RecyclerView.ViewHolder{
        TextView tvName,tvEmail, tvPhone,tvAddress;
        ConstraintLayout clParent;
        ExtendedFloatingActionButton fabEdit, fabDelete;
        public BindViewHolder(@NonNull View itemView) {
            super(itemView);
        }

        void bindData(int position){
            tvName = itemView.findViewById(R.id.tvName);
            tvEmail = itemView.findViewById(R.id.tvEmail);
            tvPhone = itemView.findViewById(R.id.tvPhone);
            tvAddress = itemView.findViewById(R.id.tvAddress);
            fabEdit =  itemView.findViewById(R.id.fabEdit);
            fabDelete = itemView.findViewById(R.id.fabDel);
            clParent = itemView.findViewById(R.id.clParent);

            tvEmail.setText(contactList.get(position).getEmailAddress());
            tvAddress.setText(contactList.get(position).getAddress());
            tvPhone.setText(contactList.get(position).getPhoneNumber());
            tvName.setText(String.format("%s %s", contactList.get(position).getFName(), contactList.get(position).getLName()));

            fabEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(v.getContext(),SaveNewRecordActivity.class);
                    intent.putExtra("CONTACT", contactList.get(position));
                    intent.putExtra("isEdit", true);
                    v.getContext().startActivity(intent);
                }
            });

            fabDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ContactListDatabase.getInstance(itemView.getContext().getApplicationContext()).getDao().deleteContactFromDb(contactList.get(position).getId());
                    contactList.remove(position);
                    notifyDataSetChanged();
                }
            });


            clParent.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    String phone[] = contactList.get(position).getPhoneNumber().split(",");
                    String addresses[] = contactList.get(position).getEmailAddress().split(",");

                    ArrayAdapter arrayAdapter =  new ArrayAdapter(v.getContext(), android.R.layout.simple_list_item_1, new String[]{"Call "+ phone[0], "Email "+addresses[0]});
                    ListPopupWindow listPopupWindow = new ListPopupWindow(v.getContext());
                    listPopupWindow.setAdapter(arrayAdapter);


                    listPopupWindow.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int index, long id) {
                            try {
                                Intent intent;
                                if (index == 0) {
                                    intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone[0], null));
                                } else {

                                    intent = new Intent(Intent.ACTION_SENDTO);
                                    intent.setData(Uri.parse("mailto:")); // only email apps should handle this
                                    intent.putExtra(Intent.EXTRA_EMAIL, addresses);
                                }
                                v.getContext().startActivity(intent);
                            }catch(Exception e){}
                            listPopupWindow.dismiss();
                        }
                    });

                    listPopupWindow.setAnchorView(itemView);
                    listPopupWindow.show();
                    return false;
                }
            });

        }
    }
}
